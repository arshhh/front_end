describe('Address Book', function(){
    
     var addressBook,
         thisContact;

         beforeEach(function (){
             
         addressBook=new AddressBook(),
         thisContact=new Contact();

         });
    it('Should be able to add the contact',function(){
        var addressBook=new AddressBook(),
         thisContact=new Contact();

        addressBook.addContact(thisContact);

        expect(addressBook.getContact(0)).toBe(thisContact);
    });


    it('Should be able to delete the contact', function() {
       

         addressBook.addContact(thisContact);
         addressBook.deleteContact(0);   

         expect(addressBook.getContact(0)).not.toBeDefined();
    });
});

describe('Async Address Book', function() {
    var addressBook=new AddressBook();

    beforeEach(function(done){
        addressBook.getInitialContacts(function() {
            done();
        });
    });
    it('should grab initial contacts', function(done) {
        var addressBook=new AddressBook();
        
        expect(addressBook.initialComplete).toBe(true);
        done();
    });
});